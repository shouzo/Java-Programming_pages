package Java20151105;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Practice_Server {
	static final String IP = "127.0.0.1";
	static final int PORT = 5000;

	public Practice_Server() {
		try {
			...			//創建 ServerSocket 物件 並設定欲綁定之PORT
			System.out.println("伺服器啟動於 : " + IP + ":" + PORT);
			System.out.println("*****************************");
			while (true) {
				...			//監聽對應的PORT 阻塞直到建立連接
				... 		//創建 DataInputStream 物件將 ServerSocket的InputStream 放入
				...			//將資料從網路串流讀取
				System.out.println(msg);
				... 		//創建 DataOutputStream 物件將 ServerSocket的OutputStream 放入
				... 		// 將資料寫入網路串流，並輸出到網路
			}
		} catch (Exception e) {}
	}
	public static void main(String[] args) {
		new Practice_Server();
	}
}