package Java20151105;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

public class Practice_client {
	static final String IP = "127.0.0.1";
	static final int PORT = 5000;
	public Practice_client() {
		try {
			...		 // 建立Socket物件 設定 IP PORT 
			...		 // 創建 DataOutputStream 物件將 ServerSocket的OutputStream 放入
			...		 // 將資料寫入網路串流，並輸出到網路
			...   	 // 創建 DataInputStream 物件將 ServerSocket的InputStream 放入
			...		 // 將資料從網路串流讀取
			System.out.println(msg);
			s.close();
		} catch (Exception e) {}
	}
	public static void main(String[] args) {
		new Practice_client();
	}
}