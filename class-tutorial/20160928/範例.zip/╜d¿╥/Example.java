package Java20151001;

public class Example {
	public static void main(String[] args) {
		int i, total = 0;
		for (i = 1; i <= 15; i++) {
			System.out.print("|" + i);
			total += i;
		}
		System.out.println("�`�M: " + total);
	}
}