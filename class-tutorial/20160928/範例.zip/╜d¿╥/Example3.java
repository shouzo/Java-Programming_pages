package Java20151001;

public class Example3 {

	public static void main(String[] args) {
		int i=1;
		//�L�a�j��
		while(true){
		System.out.println("i="+i);
		i++;
		}
	}
}