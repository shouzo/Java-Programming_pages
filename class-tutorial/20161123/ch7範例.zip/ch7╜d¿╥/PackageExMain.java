package otherMain;

import week7_Shape.Circle;
import week7_Shape.Rectangle;

public class PackageExMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle c = new Circle(6.0);
		Rectangle r = new Rectangle(10.0, 15.0);
		c.area();
		r.area();
	}

}
