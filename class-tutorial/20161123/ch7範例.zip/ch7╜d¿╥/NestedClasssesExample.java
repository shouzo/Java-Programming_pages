package week7;

class NestedClasses {
    private int outernumber = 33;
     
    public void printNumber() {
        System.out.println("�L�X�~�h���O���ƭ�");
        System.out.println(outernumber);
    }
     
    public void event() {
        InnerClass i = new InnerClass();
        i.printInner();
    }
    
     
    class InnerClass {
        private int innernumber = 77;
         
        public void printInner() {
            System.out.println("�L�X���h���O���ƭ�");
            System.out.println(innernumber);
        }
        public void setInner(int innernumber){
        	this.innernumber = innernumber;
        }
         
    }
     
}

public class NestedClasssesExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NestedClasses nc = new NestedClasses();
        nc.printNumber();
        nc.event();
        NestedClasses.InnerClass ncic = nc.new InnerClass();
        ncic.setInner(55);
        ncic.printInner();
	}

}
