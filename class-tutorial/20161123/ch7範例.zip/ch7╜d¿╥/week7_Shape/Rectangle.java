package week7_Shape;

public class Rectangle  implements Shape{
	private double width, height;
	public Rectangle(double width,double height){
		this.width = width;this.height=height;} 
	public void area(){
		System.out.println("����έ��n: "+ width*height);
	}
}
