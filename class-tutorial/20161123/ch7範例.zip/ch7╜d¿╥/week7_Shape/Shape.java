package week7_Shape;

public interface Shape {
	void area();
}
