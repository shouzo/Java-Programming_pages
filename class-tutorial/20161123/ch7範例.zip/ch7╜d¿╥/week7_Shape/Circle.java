package week7_Shape;

public class Circle  implements Shape{
	private double r;
	public Circle (double r){this.r = r;}
	public void area(){
		System.out.println("�ꭱ�n: "+ Math.PI*r*r);
	}
}
