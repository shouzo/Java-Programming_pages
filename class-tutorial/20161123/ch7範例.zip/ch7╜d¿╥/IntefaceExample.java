package week7;

abstract class Shape{
	public double x,y;
}
interface AreaInterface{
	final double PI = 3.1415926;
	void area();
}
class Circle extends Shape implements AreaInterface{
	private double r;
	public Circle(double x, double y, double r){
		this.x=x;this.y=y;this.r=r;
	}
	public void area(){
		System.out.println("X �y��: "+x);
		System.out.println("Y �y��: "+y);
		System.out.println("��b�|: "+r);
		System.out.println("�ꭱ�n: "+(PI*r*r));
	}
}

public class IntefaceExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle c = new Circle(5.0, 5.0, 8.0);
		c.area();
		System.out.println("PI �`��: "+AreaInterface.PI);
	}

}
