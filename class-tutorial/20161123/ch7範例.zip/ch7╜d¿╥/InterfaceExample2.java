package week7;

interface Shape{
	void area();
}
class Circle implements Shape{
	private double r;
	public Circle (double r){this.r = r;}
	public void area(){
		System.out.println("�ꭱ�n: "+ Math.PI*r*r);
	}
}
class Rectangle implements Shape{
	private double width, height;
	public Rectangle(double width,double height){
		this.width = width;this.height=height;} 
	public void area(){
		System.out.println("����έ��n: "+ width*height);
	}
}

public class InterfaceExample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape a = null;
		Circle c = new Circle(6.0);
		Rectangle r = new Rectangle(10.0, 15.0);
		for(int i = 1;i<=2;i++){
			switch(i){
			case 1: a=c; break;
			case 2: a=r; break;
			}
			a.area();
		}
	}

}
