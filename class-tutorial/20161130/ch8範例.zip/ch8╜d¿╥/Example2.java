package excptionHandle;

public class Example2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			int[] a = new int[2];
			for(int i = 2; i > -1 ; i--){
				System.out.println("6/"+i+"�p�⵲�G: "+ 6/i);
				a[i] = 0;
			}	
		}catch(ArithmeticException | 
				ArrayIndexOutOfBoundsException ex){
			System.out.println("�ҥ~����: "+ ex.getMessage());
			System.out.println("�ҥ~��]: ");
			ex.printStackTrace();
		}finally{
			System.out.println("���~�B�z����");
		}
		System.out.println("�{������!!");
	}
}
