package excptionHandle;
import java.io.*;

public class Example5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			String str,fileName = "C:\\test.txt";
			FileReader file = new FileReader(fileName);
			BufferedReader input = new BufferedReader(file);
			System.out.println("�ɮ�: "+fileName);
			System.out.println("----------------");
			while( (str = input.readLine()) != null ){
				System.out.println(str);
			}
			input.close();
		}catch(IOException ex){
			System.out.println("�ҥ~����: "+ ex.getMessage());
			System.out.println("�ҥ~��]: ");
			ex.printStackTrace();
		}
	}
}
