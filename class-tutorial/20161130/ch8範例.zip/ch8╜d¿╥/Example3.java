package excptionHandle;

import java.util.Scanner;

public class Example3 {
	static double cal(double a, double b, double c){
		double value;
		if (c == 0)//��X IllegalArgumentException �ҥ~
			throw new IllegalArgumentException("c����O0!!");
		else
			value = a*b/c;
		if(value < 0)
			throw new IllegalArgumentException("�B�⵲�G�p��0");
		return value;
	}
	public static void main(String[] args) {
		double result;
		double[] a = new double[3];
		Scanner sc = new Scanner(System.in);
		try{
			for(int i=0;i<3;i++)
				a[i] = sc.nextDouble();
			result = cal(a[0], a[1], a[2]);
			System.out.println("�p�⵲�G: "+ result);
		}catch(IllegalArgumentException | 
				ArrayIndexOutOfBoundsException ex){
			System.out.println("�ҥ~����: "+ ex.getMessage());
			System.out.println("�ҥ~��]: ");
			ex.printStackTrace();
		  }
		sc.close();
	}
}
